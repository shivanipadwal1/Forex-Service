package com.sprint.forex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForexApplicationTests {

	@Test
	void contextLoads() {
	}

}
