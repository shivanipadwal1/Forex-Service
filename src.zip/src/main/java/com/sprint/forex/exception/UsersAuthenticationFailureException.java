package com.sprint.forex.exception;

public class UsersAuthenticationFailureException extends RuntimeException {
	
	public UsersAuthenticationFailureException(String msg) {
        super(msg);
    }

}
