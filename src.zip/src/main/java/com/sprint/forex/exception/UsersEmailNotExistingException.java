package com.sprint.forex.exception;

public class UsersEmailNotExistingException extends RuntimeException {
	public UsersEmailNotExistingException(String msg) {
		super(msg);
	}

}
