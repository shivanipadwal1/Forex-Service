package com.sprint.forex.exception;

public class AdminEmailNotExisting extends RuntimeException{

	public AdminEmailNotExisting(String msg) {
			
			super(msg);
		}


}
