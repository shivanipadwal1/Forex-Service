package com.sprint.forex.exception;


	public class AdminAuthenticationFailureException extends RuntimeException{
		
		 public AdminAuthenticationFailureException(String msg) {
				
				super(msg);
			}

		}

