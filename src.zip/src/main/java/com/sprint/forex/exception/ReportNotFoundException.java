package com.sprint.forex.exception;

public class ReportNotFoundException {

}
