package com.sprint.forex.exception;

public class UsersNotFoundException extends RuntimeException {
	
	public UsersNotFoundException(String msg)
	{
		super(msg);
	}

}

