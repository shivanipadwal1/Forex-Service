package com.sprint.forex.exception;

public class EmailNotExistingException extends RuntimeException {
	
	public EmailNotExistingException(String msg)
	{
		super(msg);
	}


}

