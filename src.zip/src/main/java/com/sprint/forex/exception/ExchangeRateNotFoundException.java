package com.sprint.forex.exception;

public class ExchangeRateNotFoundException extends RuntimeException {
	public ExchangeRateNotFoundException(String message) {
		super(message);
	}

	
}
