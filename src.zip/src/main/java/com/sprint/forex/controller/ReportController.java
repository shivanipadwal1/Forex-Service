package com.sprint.forex.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.sprint.forex.entity.Transaction;
import com.sprint.forex.dto.ReportDto;

import com.sprint.forex.repository.TransactionRepository;
import com.sprint.forex.service.ReportService;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class ReportController {
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private TransactionRepository transactionRepository;

	@GetMapping("/report/{transactionId}")
	public ResponseEntity<byte[]> getReport(@PathVariable int transactionId) throws IOException, DocumentException {
	    Transaction transaction = transactionRepository.findById(transactionId)
	            .orElseThrow(() -> new EntityNotFoundException("Transaction not found with id: " + transactionId));

	    // Generate report based on transaction and return as byte[]
	    byte[] reportContent = generateReport(transaction);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_PDF);
	    headers.setContentDisposition(ContentDisposition.builder("attachment")
	        .filename("report.pdf")
	        .build());

	    return new ResponseEntity<>(reportContent, headers, HttpStatus.OK);
	}

	public byte[] generateReport(Transaction transaction) throws DocumentException {
	    // Get the transaction details from the transaction object
	    int transactionId = transaction.getTransactionId();
	    LocalDate transactionDate = transaction.getTransactionDate();
	    String senderName = transaction.getSenderName();
	    String receiverName = transaction.getReceiverName();
	    long senderAccNo = transaction.getSenderAccNo();
	    long receiverAccNo = transaction.getReceiverAccNo();
	    long sendingAmount = transaction.getSendingAmount();

	    // Create a PDF document and add some content
	    Document document = new Document();
	    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	    PdfWriter.getInstance(document, outputStream);
	    document.open();
	    document.add(new Paragraph("Transaction ID: " + transactionId));
	    document.add(new Paragraph("Transaction Date: " + transactionDate.toString()));
	    document.add(new Paragraph("Sender Name: " + senderName));
	    document.add(new Paragraph("Receiver Name: " + receiverName));
	    document.add(new Paragraph("Sender Account Number: " + senderAccNo));
	    document.add(new Paragraph("Receiver Account Number: " + receiverAccNo));
	    document.add(new Paragraph("Sending Amount: " + sendingAmount));
	    // Add other report content as needed
	    document.close();

	    // Return the report as a byte[]
	    return outputStream.toByteArray();
	}

}